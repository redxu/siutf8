Usage:
Copy msimg32.dll / loaderdll.dll loader.exe to Source Insight 3.x dir;
if Run Source Insight plugin works,then msimg32 auto works!
Otherwise,use loader.exe to Start SI.